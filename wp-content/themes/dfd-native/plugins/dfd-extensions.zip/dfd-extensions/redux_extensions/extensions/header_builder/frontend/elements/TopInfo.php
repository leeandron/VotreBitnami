<?php
if (!defined('ABSPATH'))
	exit;

class DfdHeaderBuilder_TopInfo extends DfdHeaderBuilderElementAbstract {

	protected $template = "topinfo";

}
