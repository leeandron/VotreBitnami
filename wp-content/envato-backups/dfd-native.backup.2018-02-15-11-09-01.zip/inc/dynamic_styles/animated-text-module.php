<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-animated-text-wrap .dfd-animated-text-block span{'
				. 'font-family: '.$vars['h2-font-family'].';'
				. 'font-size: '.$vars['h2-font-size'].';'
				. 'font-style: '.$vars['h2-font-style'].';'
				. 'font-weight: '.$vars['h2-font-weight'].';'
				. 'text-transform: '.$vars['h2-text-transform'].';'
				. 'line-height: '.$vars['h2-line-height'].';'
				. 'letter-spacing: '.$vars['h2-letter-spacing'].';'
				. 'color: '.$vars['h2-color'].';'
			. '}';
