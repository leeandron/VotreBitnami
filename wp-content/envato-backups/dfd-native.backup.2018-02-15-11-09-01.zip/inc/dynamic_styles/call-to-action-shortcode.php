<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-call-to-action-wrap .main-tilted-decoration:before {background: '.$vars['main_site_color'].';}';