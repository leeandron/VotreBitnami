<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-animate-heading-wrap .title-container.animate-container, .dfd-animate-heading-wrap .subtitle-container.animate-container {background: '.$vars['main_site_color'].';}';