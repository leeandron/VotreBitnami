<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-presen-bg-decor-wrap .head-wrap .icon-wrap {color: '.$vars['main_site_color'].';}';