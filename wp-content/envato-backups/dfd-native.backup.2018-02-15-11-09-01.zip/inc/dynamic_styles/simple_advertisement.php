<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-simple-advertisement div.box-title {'
				. 'font-family: '.$vars['h3-font-family'].';'
			. '}';
$output .= '.dfd-simple-advertisement .box-info {'
				. 'background-color: '.$vars['main_site_color'].';'
			. '}';
