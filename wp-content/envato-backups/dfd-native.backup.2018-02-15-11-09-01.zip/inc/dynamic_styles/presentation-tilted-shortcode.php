<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-presentation-tilted-wrap .dfd-presentation-tilted-item .head-container .icon-wrap {color: '.$vars['main_site_color'].';}';