<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .=	'.dfd-services-wrap.style-2 .dfd-service-item .dfd-service-front .icon-wrap .icon-decoration:after,'
			. '.dfd-services-wrap.flip .dfd-service-back,'
			. '.dfd-services-wrap.cubic .dfd-service-back {background: '.$vars['main_site_color'].';}';